* tiene el objetivo de:
* es una alternativa para la producción de arrabio
* alternativa frente al incremento de la demanda por parte de la [[siderúrgica integrada]]
* no necesariamente necesita coque
* necesita carbón de una cierta calidad
* acortar el proceso de producción de acero
* eliminación de plantas de coque
* eliminar planta de tratamiento de materiales
* equivale a la zona de la reducción directa con el carbón 
* no como la zona indirecta que se reduce con gas reductor
* permite genera un gas reductor en exceso para generar electricidad que se vende
### Análisis del grafico
* que pasa con la cantidad de gas reductor y los requerimientos? en 4 estoy consumiendo más carbón del necesario, y genero mayor gas reductor para vender gas para electricidad 
	* este es el [[Proceso-COREX]]
* en la zona AP estoy produciendo más de lo que necesito
* el punto P es el ideal
* de PD necesito más de lo que estoy produciendo 
* estoy produciendo menos gas de lo que necesito
* línea roja son los requerimientos 
* en el punto 2) el requerimiento es más bajo y produzco harto?
* lo primero es satisfacer la línea roja o la de los requerimientos 
* la zona de reserva térmica va tirando los gases de gasificación in situ
* equivale al segundo reactor de fusión reductora 
* [[Proceso BSC]]
* [[reducción directa]]
* la producción de arrabio es la parte más pesada de la inversión
* en países como Colombia tienen mini mills y no siderurgia integrada
* se puede optimizar mediante el proceso HIsmelt
![[fusión reductora-1701286772265.jpeg]]

### Pregunta sobre gráfico 
![[fusión reductora-1701294381541.jpeg]]
- CD representa la línea de los requerimientos, estos son gráficos para la fusión reductora
- AB representa lo que produzco
- al menos tengo que [[satisfacer los requerimientos de gas]]
- en este gráfico se comparan dos conceptos, el primero es la pre reducción (hecha por ejemplo en un reactor tipos shaft furnace o bien uno de lecho fluidizado) y el segundo es la reducción, posterior a la pre reducción. 
- en PD necesito más requerimiento de lo que estoy produciendo, entonces estoy produciendo PB (la línea de abajo) o también produciendo menos gas del que necesito.
	- y al revés, ocurre que en AP estoy produciendo más gas que el que necesito 
- el punto P es un punto de equilibrio o punto ideal 
- Corex está en la zona 4 y tiene un alto excedente de energía 
- HIsmelt
* [[zona 1]] en donde satisface los requerimientos, aporte de gas reductor es mayor entonces! este es el [[proceso-HIsmelt]]
	* estoy produciendo más gas de lo que requiero, por ende:
* hay que hacer algo con ese gas
* El proceso DIOS estaría ubicado en el [[punto 2]] del diagrama! [[proceso-DIOS]]
