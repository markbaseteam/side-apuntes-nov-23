3Fe + CH4 = FE3C + 2H2
3FE + 2CO = FE3C + CO2
* produce el producto llamado DRI que es cementita Fe3C en el proceso HyL por ejemplo pata alimentar el reactor eléctrico
* produce el pellet o hierro esponja
* en cambio el hierro briquetas tenía otro nombre, HBI que se logra vender como commoditie