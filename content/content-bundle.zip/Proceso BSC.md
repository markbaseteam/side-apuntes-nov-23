- Su nombre es BSC ya que fue diseñado por "British Steel Corporation"
- originalmente evolucionó de un desarrollo destinado a aumentar el consumo de chatarra en el [[diferencia-siemens-martin-con-BOF|Proceso BOF]] por adición de carbón y de oxígeno.
- el proceso se concibió como una operación de reducción y fusión en dos etapas
- en donde los gases y minerales de hierro pre-reducidos|[[pre reducción]] se transferían entre las etapas del proceso 
- ==una de las principales características importantes de este proceso es la [[unidad de fusión de doble cámara]]==
- este punto de enlace entre la pre reducción y la reducción final del proceso está en el área 4 de la figura 1-4, que es del gráfico de los requerimientos en [[fusión reductora]]
- acá se encuentra la double chamber o twin chamber que se estaba mencionando:
![[Proceso BSC-1701382825142.jpeg]]
- se ocupan los [[desulfurantes]]
- [[proceso-HIsmelt]]
- [[proceso-DIOS]]
- [[Proceso-COREX]]

- [[Preguntas-C2-de-Siderurgia]]