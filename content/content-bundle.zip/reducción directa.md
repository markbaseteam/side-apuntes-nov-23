* nos vamos a ir por la ruta de las mini mills
* necesitamos scrap o chatarra
* hay una relación directa entre países desarrollados y los países menos desarrollados, en los más desarrollados cambian de autos o electrodomésticos cada 4 años, se genera mayor cantidad de chatarra
* procesos que no generan un material fundido como el alto horno
	* no generan arrabio entonces, lo que generan en este caso son los pellets de acero o las briquetas. 
* sino que producen un material metalizado que alimenta el horno eléctrico 

* menores costo de inversión
* menores capacidades
* materias primas de menor calidad
* mayor versatilidad en la operación
* producen hierro esponja
* direct reduce iron que son los pellets metalizados

[[proceso quimico y rxnes]]

* 70 % de la producción por medio de reducción directa se hace por [[shaft furnace]], MIDREX es el que la lleva
* otra alternativa es la [[reactor-tipo-baño-reducción-directa]]