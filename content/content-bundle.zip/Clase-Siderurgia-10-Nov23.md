- [[fusión reductora]], segunda alternativa mini mills 
* mercado de chatarra que me asegure la materia prima?
* tengo que importar mineral de hierro y puedo hacer un proceso de [[reducción directa]]
* todo esto frente al aumento de la demanda
* instalar un segundo convertidor no es una gran inversión 
* el sistema de manejo de material gasta más en una [[siderúrgica integrada]]
* la segunda zona se preocupa de generar los gases de reducción 
* donde se cargan los minerales y fundentes? en el reactor de prereduccion
* y esto alimenta al reactor de [[fusión reductora]]

- link de la clase grabada del profe: https://udeconce.sharepoint.com/:v:/r/sites/Section_388093/Documentos%20compartidos/General/Recordings/Solo%20vista/Reuni%C3%B3n%20en%20_General_-20231109_162116-Grabaci%C3%B3n%20de%20la%20reuni%C3%B3n.mp4?csf=1&web=1&e=gW1pa2

### Clase grabada del profe
- La revisé el 17 de Noviembre de 2023
- [[charla-siderurgia-17_11-23]]
- desventajas que se explican en el alto horno
	- altos costos de capital
	- por el tamaño, la integración del alto horno, la cokería y la preparación de carga
	- [[dos líneas para enfrentar problemas]] de la [[siderúrgica integrada]] 
- la [[fusión reductora]] tiene el objetivo de 
	- acortar el proceso productivo de acero, [[siderurgia secundaria]]
	- eliminar la planta de coque
	- eliminar las plantas de preparación de materias primas
	- reducir idealmente eliminar la dependencia de carbón coquificable
- las limitaciones de un alto horno están dadas por su tamaño
- hay una interconexión virtuosa entre:
	- zona de pre-reducción
	- reducción final con fusión
	- control de la energía y aporte de reductores
	- conexión virtuosa de cada subproceso
- [[Clase-descarbonización-28_11-Side-online]]